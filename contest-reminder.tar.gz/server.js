const express = require('express');
const cors = require('cors');
const cron = require('node-cron');
const nodemailer = require('nodemailer');
const axios = require('axios');
const fs = require('fs').promises;
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Data storage
const DATA_FILE = path.join(__dirname, 'data.json');

// Initialize data file
async function initDataFile() {
  try {
    await fs.access(DATA_FILE);
  } catch {
    await fs.writeFile(DATA_FILE, JSON.stringify({ subscribers: [], contests: [] }));
  }
}

// Read data
async function readData() {
  const data = await fs.readFile(DATA_FILE, 'utf8');
  return JSON.parse(data);
}

// Write data
async function writeData(data) {
  await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2));
}

// Email transporter
let transporter;
if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });
}

// Twilio client
let twilioClient;
if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
  const twilio = require('twilio');
  twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
}

// Fetch contests from various platforms
async function fetchContests() {
  const contests = [];
  
  try {
    // Codeforces
    const cfResponse = await axios.get('https://codeforces.com/api/contest.list');
    if (cfResponse.data.status === 'OK') {
      const upcomingCF = cfResponse.data.result
        .filter(c => c.phase === 'BEFORE')
        .map(c => ({
          platform: 'Codeforces',
          name: c.name,
          startTime: new Date(c.startTimeSeconds * 1000),
          duration: c.durationSeconds / 3600, // in hours
          url: `https://codeforces.com/contest/${c.id}`
        }));
      contests.push(...upcomingCF);
    }
  } catch (error) {
    console.error('Error fetching Codeforces contests:', error.message);
  }

  try {
    // CodeChef
    const ccResponse = await axios.get('https://www.codechef.com/api/list/contests/all?sort_by=START&sorting_order=asc&offset=0&mode=all');
    if (ccResponse.data.present_contests || ccResponse.data.future_contests) {
      const upcomingCC = (ccResponse.data.future_contests || [])
        .map(c => ({
          platform: 'CodeChef',
          name: c.contest_name,
          startTime: new Date(c.contest_start_date_iso),
          duration: (new Date(c.contest_end_date_iso) - new Date(c.contest_start_date_iso)) / (1000 * 3600),
          url: `https://www.codechef.com/${c.contest_code}`
        }));
      contests.push(...upcomingCC);
    }
  } catch (error) {
    console.error('Error fetching CodeChef contests:', error.message);
  }

  try {
    // LeetCode
    const lcResponse = await axios.get('https://leetcode.com/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      data: JSON.stringify({
        query: `{
          allContests {
            title
            titleSlug
            startTime
            duration
          }
        }`
      })
    });
    
    if (lcResponse.data?.data?.allContests) {
      const now = Date.now() / 1000;
      const upcomingLC = lcResponse.data.data.allContests
        .filter(c => c.startTime > now)
        .map(c => ({
          platform: 'LeetCode',
          name: c.title,
          startTime: new Date(c.startTime * 1000),
          duration: c.duration / 3600,
          url: `https://leetcode.com/contest/${c.titleSlug}`
        }));
      contests.push(...upcomingLC);
    }
  } catch (error) {
    console.error('Error fetching LeetCode contests:', error.message);
  }

  try {
    // AtCoder
    const acResponse = await axios.get('https://atcoder.jp/contests/?lang=en');
    // Note: AtCoder requires HTML parsing, simplified for now
  } catch (error) {
    console.error('Error fetching AtCoder contests:', error.message);
  }

  // Sort by start time
  contests.sort((a, b) => a.startTime - b.startTime);
  
  return contests;
}

// Send email notification
async function sendEmail(to, subject, html) {
  if (!transporter) {
    console.log('Email not configured. Would send to:', to);
    return;
  }

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to,
      subject,
      html
    });
    console.log(`Email sent to ${to}`);
  } catch (error) {
    console.error('Error sending email:', error.message);
  }
}

// Send SMS notification
async function sendSMS(to, message) {
  if (!twilioClient) {
    console.log('SMS not configured. Would send to:', to);
    return;
  }

  try {
    await twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to
    });
    console.log(`SMS sent to ${to}`);
  } catch (error) {
    console.error('Error sending SMS:', error.message);
  }
}

// Check and send reminders
async function checkAndSendReminders() {
  const data = await readData();
  const contests = await fetchContests();
  
  // Update stored contests
  data.contests = contests;
  await writeData(data);

  const now = new Date();
  
  for (const contest of contests) {
    const timeUntilStart = contest.startTime - now;
    const hoursUntilStart = timeUntilStart / (1000 * 3600);
    
    // Send reminder 24 hours before
    if (hoursUntilStart > 23 && hoursUntilStart < 25) {
      for (const subscriber of data.subscribers) {
        if (subscriber.preferences.includes('email')) {
          const emailHtml = `
            <h2>Contest Reminder: ${contest.name}</h2>
            <p><strong>Platform:</strong> ${contest.platform}</p>
            <p><strong>Starts in:</strong> 24 hours</p>
            <p><strong>Start Time:</strong> ${contest.startTime.toLocaleString()}</p>
            <p><strong>Duration:</strong> ${contest.duration} hours</p>
            <p><a href="${contest.url}">Contest Link</a></p>
          `;
          await sendEmail(subscriber.email, `Contest Tomorrow: ${contest.name}`, emailHtml);
        }
        
        if (subscriber.preferences.includes('sms') && subscriber.phone) {
          const smsText = `Contest Tomorrow: ${contest.name} on ${contest.platform} at ${contest.startTime.toLocaleString()}. ${contest.url}`;
          await sendSMS(subscriber.phone, smsText);
        }
      }
    }
    
    // Send reminder 1 hour before
    if (hoursUntilStart > 0.5 && hoursUntilStart < 1.5) {
      for (const subscriber of data.subscribers) {
        if (subscriber.preferences.includes('email')) {
          const emailHtml = `
            <h2>Contest Starting Soon: ${contest.name}</h2>
            <p><strong>Platform:</strong> ${contest.platform}</p>
            <p><strong>Starts in:</strong> 1 hour</p>
            <p><strong>Start Time:</strong> ${contest.startTime.toLocaleString()}</p>
            <p><a href="${contest.url}">Join Now</a></p>
          `;
          await sendEmail(subscriber.email, `Starting in 1 Hour: ${contest.name}`, emailHtml);
        }
        
        if (subscriber.preferences.includes('sms') && subscriber.phone) {
          const smsText = `Starting in 1 hour: ${contest.name} on ${contest.platform}. ${contest.url}`;
          await sendSMS(subscriber.phone, smsText);
        }
      }
    }
  }
}

// API Routes

// Get all upcoming contests
app.get('/api/contests', async (req, res) => {
  try {
    const contests = await fetchContests();
    res.json({ success: true, contests });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Subscribe
app.post('/api/subscribe', async (req, res) => {
  try {
    const { email, phone, preferences } = req.body;
    
    if (!email) {
      return res.status(400).json({ success: false, error: 'Email is required' });
    }

    const data = await readData();
    
    // Check if already subscribed
    const existingIndex = data.subscribers.findIndex(s => s.email === email);
    
    const subscriber = {
      email,
      phone: phone || null,
      preferences: preferences || ['email'],
      subscribedAt: new Date().toISOString()
    };
    
    if (existingIndex >= 0) {
      data.subscribers[existingIndex] = subscriber;
    } else {
      data.subscribers.push(subscriber);
    }
    
    await writeData(data);
    
    // Send confirmation email
    if (transporter) {
      await sendEmail(
        email,
        'Welcome to Contest Reminder!',
        '<h2>You\'re subscribed!</h2><p>You\'ll receive reminders for upcoming coding contests from Codeforces, CodeChef, LeetCode, and more.</p>'
      );
    }
    
    res.json({ success: true, message: 'Subscribed successfully!' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Unsubscribe
app.post('/api/unsubscribe', async (req, res) => {
  try {
    const { email } = req.body;
    
    const data = await readData();
    data.subscribers = data.subscribers.filter(s => s.email !== email);
    await writeData(data);
    
    res.json({ success: true, message: 'Unsubscribed successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get all subscribers (for admin)
app.get('/api/subscribers', async (req, res) => {
  try {
    const data = await readData();
    res.json({ success: true, subscribers: data.subscribers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Schedule cron job to check for contests every hour
cron.schedule('0 * * * *', () => {
  console.log('Checking for contest reminders...');
  checkAndSendReminders();
});

// Initial fetch on startup
initDataFile().then(() => {
  console.log('Data file initialized');
  checkAndSendReminders();
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
